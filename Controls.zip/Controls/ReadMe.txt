Hey there I am not much experienced with these kind of work and this my first project.

How To Import?
if you are on gamehub press on the three dots then go to pc settings from there go to controls then go to edit controls/Switch Touch Control Layout then from there at top right there is a import button click on it then use the give gta file you got along with these read me file

How To Use?
All button have been provided for all kinds of work 
To shoot you can long press anywhere on screen or just use the up arrow  ⬆️ ⬆️ ⬆️ used to drive the car front both works 

Feedbacks:
You can reachout to me on discord on : fearles_striker
All the feedbacks are appreciated 

Thanks 